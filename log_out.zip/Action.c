Action()
{
	web_reg_save_param_ex(
		"ParamName=userSession",
		"LB=userSession\" value=\"",
		"RB=\"",
		SEARCH_FILTERS,
		LAST);
	
	web_url("WebTours", 
		"URL=http://localhost:1080/WebTours", 
		"TargetFrame=", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	lr_start_transaction("Script_log_out");

	lr_start_transaction("login");

	web_add_header("Origin", 
		"http://localhost:1080");

	web_reg_find("Text/IC=User password was correct",
		LAST);

	web_submit_data("login.pl", 
		"Action=http://localhost:1080/cgi-bin/login.pl", 
		"Method=POST", 
		"TargetFrame=body", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=userSession", "Value={userSession}", ENDITEM, 
		"Name=username", "Value=jojo", ENDITEM, 
		"Name=password", "Value=bean", ENDITEM, 
		"Name=login.x", "Value=57", ENDITEM, 
		"Name=login.y", "Value=14", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		LAST);


	lr_end_transaction("login",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("flights");

	web_url("Search Flights Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("flights",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("find_flight");

	web_submit_data("reservations.pl", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=depart", "Value=Los Angeles", ENDITEM, 
		"Name=departDate", "Value={departDate}", ENDITEM, 
		"Name=arrive", "Value={arrive}", ENDITEM, 
		"Name=returnDate", "Value=12/12/2066", ENDITEM, 
		"Name=numPassengers", "Value=50", ENDITEM, 
		"Name=seatPref", "Value={seatPref}", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=findFlights.x", "Value=57", ENDITEM, 
		"Name=findFlights.y", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=roundtrip", ENDITEM, 
		"Name=.cgifields", "Value=seatType", ENDITEM, 
		"Name=.cgifields", "Value=seatPref", ENDITEM, 
		LAST);

	lr_end_transaction("find_flight",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("flight_selection");

	web_submit_data("reservations.pl_2", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=outboundFlight", "Value=370;327;{departDate}", ENDITEM, 
		"Name=numPassengers", "Value=50", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=seatPref", "Value={seatPref}", ENDITEM, 
		"Name=reserveFlights.x", "Value=49", ENDITEM, 
		"Name=reserveFlights.y", "Value=9", ENDITEM, 
		LAST);

	lr_end_transaction("flight_selection",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("Payment_Details");

	web_submit_data("reservations.pl_3", 
		"Action=http://localhost:1080/cgi-bin/reservations.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/reservations.pl", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=firstName", "Value=Jojo", ENDITEM, 
		"Name=lastName", "Value=Bean", ENDITEM, 
		"Name=address1", "Value=", ENDITEM, 
		"Name=address2", "Value=", ENDITEM, 
		"Name=pass1", "Value=Jojo Bean", ENDITEM, 
		"Name=pass2", "Value=", ENDITEM, 
		"Name=pass3", "Value=", ENDITEM, 
		"Name=pass4", "Value=", ENDITEM, 
		"Name=pass5", "Value=", ENDITEM, 
		"Name=pass6", "Value=", ENDITEM, 
		"Name=pass7", "Value=", ENDITEM, 
		"Name=pass8", "Value=", ENDITEM, 
		"Name=pass9", "Value=", ENDITEM, 
		"Name=pass10", "Value=", ENDITEM, 
		"Name=pass11", "Value=", ENDITEM, 
		"Name=pass12", "Value=", ENDITEM, 
		"Name=pass13", "Value=", ENDITEM, 
		"Name=pass14", "Value=", ENDITEM, 
		"Name=pass15", "Value=", ENDITEM, 
		"Name=pass16", "Value=", ENDITEM, 
		"Name=pass17", "Value=", ENDITEM, 
		"Name=pass18", "Value=", ENDITEM, 
		"Name=pass19", "Value=", ENDITEM, 
		"Name=pass20", "Value=", ENDITEM, 
		"Name=pass21", "Value=", ENDITEM, 
		"Name=pass22", "Value=", ENDITEM, 
		"Name=pass23", "Value=", ENDITEM, 
		"Name=pass24", "Value=", ENDITEM, 
		"Name=pass25", "Value=", ENDITEM, 
		"Name=pass26", "Value=", ENDITEM, 
		"Name=pass27", "Value=", ENDITEM, 
		"Name=pass28", "Value=", ENDITEM, 
		"Name=pass29", "Value=", ENDITEM, 
		"Name=pass30", "Value=", ENDITEM, 
		"Name=pass31", "Value=", ENDITEM, 
		"Name=pass32", "Value=", ENDITEM, 
		"Name=pass33", "Value=", ENDITEM, 
		"Name=pass34", "Value=", ENDITEM, 
		"Name=pass35", "Value=", ENDITEM, 
		"Name=pass36", "Value=", ENDITEM, 
		"Name=pass37", "Value=", ENDITEM, 
		"Name=pass38", "Value=", ENDITEM, 
		"Name=pass39", "Value=", ENDITEM, 
		"Name=pass40", "Value=", ENDITEM, 
		"Name=pass41", "Value=", ENDITEM, 
		"Name=pass42", "Value=", ENDITEM, 
		"Name=pass43", "Value=", ENDITEM, 
		"Name=pass44", "Value=", ENDITEM, 
		"Name=pass45", "Value=", ENDITEM, 
		"Name=pass46", "Value=", ENDITEM, 
		"Name=pass47", "Value=", ENDITEM, 
		"Name=pass48", "Value=", ENDITEM, 
		"Name=pass49", "Value=", ENDITEM, 
		"Name=pass50", "Value=", ENDITEM, 
		"Name=creditCard", "Value=123456789", ENDITEM, 
		"Name=expDate", "Value=2019", ENDITEM, 
		"Name=oldCCOption", "Value=", ENDITEM, 
		"Name=numPassengers", "Value=50", ENDITEM, 
		"Name=seatType", "Value=First", ENDITEM, 
		"Name=seatPref", "Value={seatPref}", ENDITEM, 
		"Name=outboundFlight", "Value=370;327;{departDate}", ENDITEM, 
		"Name=advanceDiscount", "Value=0", ENDITEM, 
		"Name=returnFlight", "Value=", ENDITEM, 
		"Name=JSFormSubmit", "Value=off", ENDITEM, 
		"Name=buyFlights.x", "Value=61", ENDITEM, 
		"Name=buyFlights.y", "Value=2", ENDITEM, 
		"Name=.cgifields", "Value=saveCC", ENDITEM, 
		LAST);

	lr_end_transaction("Payment_Details",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("Itinerary");

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Itinerary",LR_AUTO);
	
	lr_think_time(5);

	lr_start_transaction("cancel_all");

	web_submit_data("itinerary.pl", 
		"Action=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/itinerary.pl", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=flightID", "Value=251458903-7784-JB", ENDITEM, 
		"Name=flightID", "Value=251458160-155103-JB", ENDITEM, 
		"Name=removeAllFlights.x", "Value=24", ENDITEM, 
		"Name=removeAllFlights.y", "Value=6", ENDITEM, 
		"Name=.cgifields", "Value=1", ENDITEM, 
		"Name=.cgifields", "Value=2", ENDITEM, 
		LAST);

	lr_end_transaction("cancel_all",LR_AUTO);

	lr_think_time(5);

	lr_start_transaction("Sign_off");

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Sign_off",LR_AUTO);

	lr_end_transaction("Script_log_out",LR_AUTO);

	return 0;
}